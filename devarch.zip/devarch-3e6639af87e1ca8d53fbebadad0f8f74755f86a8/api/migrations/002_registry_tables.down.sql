DROP TABLE IF EXISTS image_tag_vulnerabilities;
DROP TABLE IF EXISTS vulnerabilities;
DROP TABLE IF EXISTS image_architectures;
DROP TABLE IF EXISTS image_tags;
DROP TABLE IF EXISTS images;
DROP TABLE IF EXISTS registries;
