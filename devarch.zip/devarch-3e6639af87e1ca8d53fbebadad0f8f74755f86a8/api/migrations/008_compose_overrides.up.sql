ALTER TABLE services ADD COLUMN compose_overrides JSONB DEFAULT '{}';
