ALTER TABLE services DROP COLUMN compose_overrides;
