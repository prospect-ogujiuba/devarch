DELETE FROM registries WHERE name IN ('dockerhub', 'ghcr', 'quay', 'gcr');
