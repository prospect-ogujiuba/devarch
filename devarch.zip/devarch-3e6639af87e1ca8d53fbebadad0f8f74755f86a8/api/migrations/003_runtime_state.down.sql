DROP TABLE IF EXISTS container_metrics;
DROP TABLE IF EXISTS container_states;
